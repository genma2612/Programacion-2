﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Biblioteca
    {
        private int _capacidad;
        private List<Libro> _libros;

        public double PrecioDeManuales
        {
            get
            {
                double precioManuales = 0;
                foreach (Libro item in this._libros)
                {
                    if (item is Manual)
                        precioManuales += (Manual)item;
                }
                return precioManuales;
            }
                
        }

        public double PrecioDNovelas
        {
            get
            {
                double precioManuales = 0;
                foreach (Libro item in this._libros)
                {
                    if (item is Novela)
                        precioManuales += (Novela)item;
                }
                return precioManuales;
            }

        }

        public double PrecioTotal
        {
            get
            {
                return this.PrecioDNovelas + this.PrecioDeManuales;
            }

        }

        public static string Mostrar(Biblioteca e)
        {
            StringBuilder retorno = new StringBuilder();
            retorno.AppendFormat("Capacidad de la biblioteca: {0}\n", e._capacidad);
            retorno.AppendFormat("Total por Manuales: {0:#,0.##}\n", e.ObtenerPrecio(ELibro.Manual));
            retorno.AppendFormat("Total por Novelas: {0:#,0.##}\n", e.ObtenerPrecio(ELibro.Novela));
            retorno.AppendFormat("Total: {0:#,0.##}\n", e.ObtenerPrecio(ELibro.Ambos));
            retorno.AppendLine("******************************************************");
            retorno.AppendLine("Listado de Libros");
            retorno.AppendLine("******************************************************");
            foreach (Libro item in e._libros)
            {
                retorno.AppendLine((string)item);
            }
            return retorno.ToString();
        }

        public static implicit operator Biblioteca(int capacidad)
        {
            Biblioteca retorno = new Biblioteca(capacidad);
            return retorno;
        }

        public static bool operator ==(Biblioteca biblioteca, Libro libro)
        {
            bool retorno = false;
            foreach (Libro item in biblioteca._libros)
            {
                if(item == libro)
                {
                    retorno = true;
                    break;
                }
            }
            return retorno;
        }

        public static bool operator !=(Biblioteca biblioteca, Libro libro)
        {
            return !(biblioteca == libro);
        }

        public static Biblioteca operator +(Biblioteca biblioteca, Libro libro)
        {
            if(biblioteca._libros.Count < biblioteca._capacidad)
            {
                foreach (Libro item in biblioteca._libros)
                {
                    if (item == libro) //No compara por tipo :/
                    {
                        Console.WriteLine("El libro ya està en la biblioteca!!!");
                        return biblioteca;
                    }
                }
                biblioteca._libros.Add(libro);
            }
            else
            {
                Console.WriteLine("No hay màs lugar en la biblioteca!!!");
            }
            return biblioteca;
        }

        private double ObtenerPrecio(ELibro tipoLibro)
        {
            double retorno = 0;
            if (tipoLibro == ELibro.Manual)
                retorno = PrecioDeManuales;
            if (tipoLibro == ELibro.Novela)
                retorno = PrecioDNovelas;
            if (tipoLibro == ELibro.Ambos)
                retorno = PrecioTotal;
            return retorno;
        }






        private Biblioteca()
        {
            _libros = new List<Libro>();
        }

        private Biblioteca(int capacidad) :this()
        {
            _capacidad = capacidad;
        }

    }
}
