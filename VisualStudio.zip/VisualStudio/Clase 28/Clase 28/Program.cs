﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Clase_28
{
    class Program
    {
        static void Main(string[] args)
        {
            Persona p = new Persona("Juan",22,0);
            Console.WriteLine("Esta es el nombre de la primer persona: " + p.getNombre());
            Console.ReadKey();
            Persona j = new Persona("Mario");
            Console.WriteLine("Esta es el nombre segunda persona: " + j.getNombre());
            Console.ReadKey();

            j.setNombre("Luis");
            j.setEdad(25);
            Console.WriteLine("Este es el nuevo nombre de la segunda persona y su edad: " + j.getNombre() + " " + j.getEdad());
            Console.WriteLine("Esta es la edad de la primer persona: " + p.getEdad());
            Console.ReadKey();
        }
    }
}
