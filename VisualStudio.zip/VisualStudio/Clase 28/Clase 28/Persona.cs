﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Clase_28
{
    class Persona
    {
        private string nombre;
        private int edad;
        private int id;

        public Persona(string nombre, int edad, int id) 
        {
            this.nombre = nombre;
            this.edad = edad;
            this.id = id;
        }

        public Persona(string nombre) 
        {
            this.edad = 0;
            this.nombre = nombre;
            this.id = 0;
        }

        public string getNombre() 
        {
            return this.nombre;
        }

        public void setNombre(string nombre) 
        {
            this.nombre = nombre;
        }

        public int getEdad()
        {
            return this.edad;
        }

        public void setEdad(int edad) 
        {
            this.edad = edad;
        }

        public int getId()
        {
            return this.id;
        }

        public void setId()
        {
            this.id = id;
        }
    }
    
}
