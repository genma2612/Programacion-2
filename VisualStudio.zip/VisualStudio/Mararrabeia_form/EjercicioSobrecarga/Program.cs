﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioSobrecarga
{
    class Program
    {
        static void Main(string[] args)
        {
            DateTime miCumpleaños = new DateTime(1996, 12, 02);


            Cosa miCosa = new Cosa(21, "nahuel", miCumpleaños);            
            DateTime fecha = DateTime.Now;

            Console.Write(miCosa.Mostrar());
            Console.ReadLine();
            miCosa.EstablecerValor(2);
            miCosa.EstablecerValor("hola");
            miCosa.EstablecerValor(fecha);
            Console.Clear();

            Console.Write(miCosa.Mostrar());
            Console.ReadLine();           
            
        }
    }
}
