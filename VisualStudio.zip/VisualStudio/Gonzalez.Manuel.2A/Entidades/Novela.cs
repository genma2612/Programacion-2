﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Novela : Libro
    {
        public EGenero genero;

        public string Mostrar()
        {
            StringBuilder retorno = new StringBuilder();
            retorno.Append(this);
            retorno.AppendFormat("Tipo: {0}\n", this.genero);
            return retorno.ToString();
        }

        public static bool operator ==(Novela novela1, Novela novela2)
        {
            bool retorno = false;
            if ((Libro) novela1 == novela2 && novela1.genero == novela2.genero)
                retorno = true;
            return retorno;
        }

        public static implicit operator double(Novela novela)
        {
            return novela._precio;
        }

        public static bool operator !=(Novela novela1, Novela novela2)
        {
            return !(novela1 == novela2);
        }

        public Novela(string titulo, float precio,Autor autor, EGenero genero) : base(titulo, autor, precio)
        {
            this.genero = genero;
        }




    }
}
