﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Autor
    {
        private string _apellido;
        private string _nombre;

        public static bool operator ==(Autor autor1, Autor autor2)
        {
            bool retorno = false;
            if (autor1._apellido == autor2._apellido && autor1._nombre == autor2._nombre)
                retorno = true;
            return retorno;
        }

        public static bool operator !=(Autor autor1, Autor autor2)
        {
            return !(autor1 == autor2);
        }

        public static implicit operator string(Autor autor)
        {
            return autor._nombre + " - " + autor._apellido;
        }

        public Autor(string nombre, string apellido)
        {
            this._apellido = apellido;
            this._nombre = nombre;
        }
    }
}
