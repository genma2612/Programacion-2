﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Manual : Libro
    {
        public ETipo tipo;

        public string Mostrar()
        {
            StringBuilder retorno = new StringBuilder();
            retorno.Append((string) this);
            retorno.AppendFormat("Tipo: {0}\n", this.tipo);
            return retorno.ToString();
        }

        public Manual(string titulo, float precio, string nombre, string apellido, ETipo tipo) :base(precio, titulo, nombre, apellido)
        {
            this.tipo = tipo;
        }

        public static bool operator ==(Manual manual1, Manual manual2)
        {
            bool retorno = false;
            if ((Libro)manual1 == manual2 && manual1.tipo == manual2.tipo)
                retorno = true;
            return retorno;
        }

        public static bool operator !=(Manual manual1, Manual manual2)
        {
            return !(manual1 == manual2);
        }

        public static implicit operator double(Manual manual)
        {
            return manual._precio;
        }
    }
}
