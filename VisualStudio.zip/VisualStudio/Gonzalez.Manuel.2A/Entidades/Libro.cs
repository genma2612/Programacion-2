﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Libro
    {
        protected Autor _autor;
        protected int _cantidadDePaginas;
        protected static Random _generadorDePaginas;
        protected float _precio;
        protected string _titulo;

        public int CantidadDePaginas
        {
            get
            {
                if(_cantidadDePaginas < 1)
                    this._cantidadDePaginas = _generadorDePaginas.Next(10, 580);
                return this._cantidadDePaginas;
            }
        }

        private static string Mostrar(Libro libro)
        {
            StringBuilder retorno = new StringBuilder();
            retorno.AppendFormat("TITULO: {0}\nCANTIDAD DE PAGINAS: {1}\nAUTOR: {2}\nPRECIO: {3}\n", libro._titulo, libro.CantidadDePaginas,(string) libro._autor, libro._precio);
            return retorno.ToString();
        }

        public static bool operator ==(Libro libro1, Libro libro2)
        {
            bool retorno = false;
            if (libro1._autor == libro2._autor && libro1._titulo == libro2._titulo)
                retorno = true;
            return retorno;
        }

        public static bool operator !=(Libro libro1, Libro libro2)
        {
            return !(libro1 == libro2);
        }

        public static explicit operator string(Libro libro)
        {
            return Libro.Mostrar(libro);
        }

        static Libro()
        {
            _generadorDePaginas = new Random();
        }

        public Libro(float precio, string titulo, string nombre, string apellido)
        {
            this._autor = new Autor(nombre, apellido);
            this._titulo = titulo;
            this._precio = precio;
        }

        public Libro(string titulo, Autor autor, float precio)
        {
            this._autor = autor;
            this._titulo = titulo;
            this._precio = precio;
        }

    }
}
