﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Mascota
    {
        private string _nombre;
        private string _raza;

        #region Propiedades
        public string Nombre
        {
            get
            {
                return this._nombre;
            }
        }
        public string Raza
        {
            get
            {
                return this._raza;
            }
        }
        #endregion
        #region Constructores
        public Mascota(string nombre, string raza)
        {
            this._nombre = nombre;
            this._raza = raza;
        }
        #endregion
        #region Metodos
        protected virtual string DatosCompletos()
        { return string.Format("{0} {1}", this._nombre, this._raza); }

        protected abstract string Ficha();
        #endregion

    }
}
