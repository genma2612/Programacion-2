﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Grupo
    {
        private List<Mascota> _manada;
        private string _nombre;
        private ETipoManada _tipo;

        #region Propiedades
        public ETipoManada TipoManada
        { set { this._tipo = value; } }

        #endregion
        #region Constructores
        private Grupo()
        {
            this._manada = new List<Mascota>();
        }
        public Grupo(string nombre)
            : this(nombre, ETipoManada.Unica)
        {
        }
        public Grupo(string nombre, ETipoManada tipo)
        {
            this._tipo = tipo;
            this._nombre = nombre;
        }
        #endregion
        #region Metodos
        public static explicit operator string(Grupo g)
        {
            StringBuilder stringBuild = new StringBuilder();
            stringBuild.AppendFormat("**{0}**\nIntegrantes:\n", g._nombre);

            foreach (Mascota mascotaA in g._manada)
            {
                if (mascotaA is Perro)
                {
                    stringBuild.AppendLine(((Perro)mascotaA).ToString());
                }
                if (mascotaA is Gato)
                {
                    stringBuild.AppendLine(((Gato)mascotaA).ToString());
                }
            }

            return stringBuild.ToString();
        }

        #endregion
        #region Operadores
        public static Boolean operator ==(Grupo e, Mascota j)
        {
            Boolean retorno = false;

            foreach (Mascota mascotaA in e._manada)
            {
                if (j is Perro)
                {
                    if (((Perro)j).Equals(mascotaA))
                    {
                        retorno = true;
                        break;
                    }
                }
                else if (j is Gato)
                {
                    if (((Gato)j).Equals(mascotaA))
                    {
                        retorno = true;
                        break;
                    }
                }
            }

            return retorno;
        }

        public static bool operator !=(Grupo grupo, Mascota mascota)
        {
            return !(grupo == mascota);
        }
        public static Grupo operator +(Grupo g, Mascota m)
        {

            if (g != m)
            {
                g._manada.Add(m);
            }
            else
            {
                Console.WriteLine("Ya esta {0}, edad {1} en el grupo");
            }
            return g;
        }
        public static Grupo operator -(Grupo g, Mascota m)
        {
            foreach (Mascota item in g._manada)
            {
                if (item == m)
                {
                    g._manada.Remove(m);
                    break;
                }
                else
                {
                    Console.WriteLine("No esta {0} en el grupo", m);
                }
            }
            return g;
        }
        #endregion
    }
}
