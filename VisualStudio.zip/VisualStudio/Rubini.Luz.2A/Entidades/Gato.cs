﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Gato : Mascota
    {
        public Gato(string nombre, string raza)
            : base(nombre, raza)
        {
        }
        #region Operadores
        public static bool operator ==(Gato gato1, Gato gato2)
        {
            bool retorno = false;
            if (gato1.Nombre == gato2.Nombre && gato1.Raza == gato2.Raza)
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator !=(Gato gato1, Gato gato2)
        {
            return !(gato1 == gato2);
        }
        #endregion
        #region Metodos
        protected override string Ficha()
        {
            return string.Format("{0}", base.DatosCompletos());
        }
        public override string ToString()
        {
            return this.Ficha();
        }
        public override bool Equals(object obj)
        {
            Boolean retorno = false;
            if (obj is Gato)
            {
                if ((Gato)obj == this)
                { retorno = true; }
            }

            return retorno;
        }
        #endregion
    }
}

