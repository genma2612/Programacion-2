﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Perro : Mascota
    {
        private int _edad;
        private bool _esAlfa;
        #region Constructores
        public Perro(string nombre, string raza)
            : this(nombre, raza, 0, false)
        {
        }
        public Perro(string nombre, string raza, int edad, bool esAlfa)
            : base(nombre, raza)
        {
            this._edad = edad;
            this._esAlfa = esAlfa;
        }
        #endregion;
        #region Metodos
        public static explicit operator int(Perro perro)
        {
            return perro._edad;
        }
        protected override string Ficha()
        {
            string s = string.Format("{0}", base.DatosCompletos());

            if (_esAlfa)
            {
                s = string.Format("{0}, alfa de la manada,", s);
            }

            s = string.Format("{0} Edad {1}", s, this._edad);

            return s;
        }
        public override string ToString()
        {
            return this.Ficha();
        }
        public override bool Equals(object obj)
        {
            Boolean retorno = false;

            if (obj is Perro)
            {
                if ((Perro)obj == this)
                { retorno = true; }
            }

            return retorno;
        }
        #endregion
        #region Operadores
        public static bool operator ==(Perro perro1, Perro perro2)
        {
            bool retorno = false;
            if (perro1.Nombre == perro2.Nombre && perro1.Raza == perro2.Raza && perro1._edad == perro2._edad)
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator !=(Perro perro1, Perro perro2)
        {
            return !(perro1 == perro2);
        }
        #endregion
    }
}
