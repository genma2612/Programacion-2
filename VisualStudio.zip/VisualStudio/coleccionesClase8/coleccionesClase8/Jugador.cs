﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace coleccionesClase8
{
    public class Jugador
    {
        private long dni;
        private string nombre;
        private float partidosJugados;
        private float promedioGoles;
        private float totalGoles;
        private Jugador _jugador;

        public float GetPromedioGoles()
        {
            this.promedioGoles = this.totalGoles / this.partidosJugados;
            return this.promedioGoles;
        }
        private Jugador()
        {
            this.dni = 1;
            this.nombre = "sin nombre";
            this.partidosJugados = 0;
            this.promedioGoles = 0;
            this.totalGoles = 0;
        }

        public Jugador(string a, long b):this()
        {
            this.nombre = a;
            this.dni = b;
        }

        public Jugador(string name, long doc, float pj, float goles):this(name, doc)
        {
            this.partidosJugados = pj;
            this.totalGoles = goles;
            this.promedioGoles = this.GetPromedioGoles();
        }

        public string MostrarDatos()
        {
            string datos="";
            datos = "nombre: " + this.nombre + "\n dni: " + this.dni +"\n pj: " + this.partidosJugados + "\n goles: "+ this.totalGoles +"\n promedio goles: "+ this.promedioGoles;
            return datos;
        }

        public static bool operator ==(Jugador j1, Jugador j2)
        {
            bool retorno = false;
            if (j1.dni == j2.dni)
            {
                retorno = true; 
            }
            return retorno;
        }

        public static bool operator !=(Jugador j1, Jugador j2)
        {
            return !(j1 == j2);
        }



          
    }
}
