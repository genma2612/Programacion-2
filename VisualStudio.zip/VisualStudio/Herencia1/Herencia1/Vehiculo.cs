﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Herencia1
{
    public class Vehiculo
    {
        protected string _patente;
        protected byte _cantRuedas;
        public enum EMarcas { Honda, Ford, Zanella, Scania, Iveco ,Fiat};
        protected EMarcas _marcas;


        protected string Mostrar()
        {
            string cadena="";
            cadena = "patente: " +this._patente + "\nruedas" + this._cantRuedas+ "\nmarca" + this._marcas+"\n";
            return cadena;  
        }

        public Vehiculo(string a, byte b, EMarcas c)
        {
            this._patente = a;
            this._cantRuedas = b;
            this._marcas = c; 
        }

        public static bool operator ==(Vehiculo a, Vehiculo b)
        {
            bool error = false;
            if (a._marcas == b._marcas && a._patente == b._patente)
                error = true;

            return error;
        }

        public static bool operator !=(Vehiculo a, Vehiculo b)
        {
            return !(a == b);
        }
    }

    public class Auto : Vehiculo
    {
        protected int _cantAsientos;
        public string MostrarAuto()            
        {
            string cadena = "";
            cadena = base.Mostrar() +"asientos: "+ this._cantAsientos+ "\n" ;
            return cadena;
        }

        public Auto(string a, byte b, EMarcas c, int d)
            : base(a, b, c)
        {
            this._cantAsientos = d;
        }

    }



    public class Camion : Vehiculo
    {
        protected float _tara;
        public string MostrarCamion()
        {
            string cadena = "";
            cadena = base.Mostrar() + "tara: " + this._tara+"\n";
            return cadena;
        }

        public Camion(string a, byte b, EMarcas c, float d)
            : base(a, b, c)
        {
            this._tara = d;
        }

    }



    public class Moto : Vehiculo
    {
        protected float _cilindrada;
        public string MostrarMoto()
        {
            string cadena = "";
            cadena = base.Mostrar() + "cilindrada: " + this._cilindrada+" \n" ;
            return cadena;
        }

        public Moto(string a, byte b, EMarcas c, float d)
            : base(a, b, c)
        {
            this._cilindrada = d;
        }
    }

    public class Lavadero
    {
        private List<Vehiculo> _vehiculos;
        private float _precioAuto;
        private float _precioCamion;
        private float _precioMoto;
        public enum EVehiculos { Auto, Camion, Moto };
        


        public Lavadero(float a, float c, float m)
        {
            this._precioAuto = a;
            this._precioCamion = c;
            this._precioMoto = m;
        }

        private Lavadero()
        {
            _vehiculos = new List<Vehiculo>() ;
        }

        public string getVehiculos()
        {
            string cadena = "";
            foreach (Vehiculo v in this._vehiculos)
            {
                if (v is Auto)
                    cadena +=((Auto)v).MostrarAuto();

                if (v is Camion)
                    cadena +=((Camion)v).MostrarCamion();

                if (v is Moto)
                    cadena += ((Moto)v).MostrarMoto();
            }
            return cadena;           
        }

        public string GetLavadero()
        {
            string cadena = "precio auto: "+ this._precioAuto + "\nprecio camion: "+this._precioCamion + "\nprecio moto: " + this._precioMoto+"\n";
            return cadena;
        }

        public double MostrarTotalFacturado(EVehiculos v)
        {
            float contA = 0, contC = 0, contM = 0;
            double total = 0;
            foreach (Vehiculo b in this._vehiculos)
            {
                if (b is Auto)
                    contA++;

                if (b is Camion)
                    contC++;

                if (b is Moto)
                    contM++;
            }
            switch (v)
            {
                case EVehiculos.Auto:
                    total = this._precioAuto * contA;
                    break;
                case EVehiculos.Camion:
                    total = this._precioCamion * contC;
                    break;
                case EVehiculos.Moto:
                    total = this._precioMoto * contM;
                    break;
                default:
                    break;
            }
            return total;
        }

        public double MostrarTotalFacturado()
        {
            double total = 0;
            total = MostrarTotalFacturado(EVehiculos.Auto) + MostrarTotalFacturado(EVehiculos.Camion) + MostrarTotalFacturado(EVehiculos.Moto);
            return total;
        }


        public static bool operator ==(Lavadero l, Vehiculo v)
        {
            bool error = false;            
            foreach (Vehiculo i in l._vehiculos)
            {
                if (i == v)
                {
                    error = true;
                    break;
                }
            }
            return error;
        }

        public static bool operator !=(Lavadero l, Vehiculo v)
        {
            return !(l == v);
        }


        public static Lavadero operator -(Lavadero l, Vehiculo v)
        {
            int cant = l._vehiculos.Count;            
            for (int i = 0; i < cant; i++)
            {
                if (v == l._vehiculos[i])
                {
                    l._vehiculos.Remove(l._vehiculos[i]);
                    break;
                }
            }
            return l;
        }


        public static Lavadero operator +(Lavadero l, Vehiculo v)
        {
            int cant = l._vehiculos.Count;
            int flag = 0;
            for (int i = 0; i < cant; i++)
            {
                if (v == l._vehiculos[i])
                {
                    flag = 1;
                    break;
                }
                if (flag == 0)
                {
                    l._vehiculos.Add(v);
                }
            }
            return l;
        }

        public static int OrdenarVehiculosPorPatente(Vehiculo a, Vehiculo b)
        {
            int retorno=0;
            if ()
                retorno = 1;

            if(a<b)
                retorno = -1;
            return retorno;
        }

    }    
     

}
